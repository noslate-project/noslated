'use strict';

process.on('request', ({ event, body, end }) => {
    console.log(event, body, '<<<');
    end(`Hello, ${event} -> ${body}!`);
});

console.log(process._hasAgent);
