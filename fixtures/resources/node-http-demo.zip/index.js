'use strict';

const { request } = require('undici');

exports.handler = async (ctx, req, res) => {
    const { body } = await request('https://www.taobao.com');

    res.setHeader('Content-Type', 'text/html');
    res.writeHead(200);
    res.end(await body.text());
}
