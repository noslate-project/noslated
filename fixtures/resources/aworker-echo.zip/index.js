'use strict';

addEventListener('fetch', event => {
  console.log('run fetch');
  const body = event.request.body;
  event.respondWith(new Response(body));
});
